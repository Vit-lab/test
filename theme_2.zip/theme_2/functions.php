<?php

remove_action('wp_head', 'wp_generator');

//if (!function_exists('enqueue_styles')) {
	function enqueue_styles() {
		wp_enqueue_style('style', get_stylesheet_uri());
	}
	add_action('wp_enqueue_scripts', 'enqueue_styles');
//}


if (!function_exists('pingback_header')) {
	function pingback_header() {
		if (is_singular() && pings_open()) {
			printf('<link rel="pingback" href="%s">' . "\n", esc_url(get_bloginfo('pingback_url')));
		}
	}
	add_action('wp_head', 'pingback_header');
}

if (!function_exists('add_viewport')) {
	function add_viewport() {
		echo apply_filters('generate_meta_viewport', '<meta name="viewport" content="width=device-width, initial-scale=1">');
	}
	add_action('wp_head', 'add_viewport');
}

if (!function_exists('test_theme_setup')) {
	function test_theme_setup() {
		register_nav_menus(
			array(
				'primary' => 'Основное меню1',
				'footer'  => 'Дополнительное меню1',
			)
		);
	}
	add_action('after_setup_theme', 'test_theme_setup' );
}


function mytheme_customize_register( $wp_customize ) {
/*
Добавляем секцию в настройки темы
*/
$wp_customize->add_section(
    // ID
    'data_site_section',
    // Arguments array
    array(
        'title' => 'Данные сайта',
        'capability' => 'edit_theme_options',
        'description' => "Тут можно указать данные сайта"
    )
);
/*
Добавляем поле контактных данных
*/
$wp_customize->add_setting(
    // ID
    'theme_contacttext',
    // Arguments array
    array(
        'default' => '',
        'type' => 'option'
    )
);
$wp_customize->add_control(
    // ID
    'theme_contacttext_control',
    // Arguments array
    array(
        'type' => 'text',
        'label' => "Текст с контактной информацией",
        'section' => 'data_site_section',
        // This last one must match setting ID from above
        'settings' => 'theme_contacttext'
    )
);
/*
Добавляем поле телефона site_telephone
*/
$wp_customize->add_setting(
    // ID
    'site_telephone',
    // Arguments array
    array(
        'default' => '',
        'type' => 'option'
    )
);
$wp_customize->add_control(
    // ID
    'site_telephone_control',
    // Arguments array
    array(
        'type' => 'text',
        'label' => "Текст с телефоном",
        'section' => 'data_site_section',
        // This last one must match setting ID from above
        'settings' => 'site_telephone'
    )
);
}
add_action( 'customize_register', 'mytheme_customize_register' );

function new_excerpt_length() {
	return 1000;
}
add_filter('excerpt_length', 'new_excerpt_length');

function mytheme_customize_register1( $wp_customize ) {
	$wp_customize->add_section(
		'excerpt_settings',
		array(
			'title' => 'Excerpt Settings',
			'capability' => 'edit_theme_options',
        	'description' => 'Тут можно указать данные сайта'
		)
	);

	$wp_customize->add_setting(
		'display_excerpt_or_full_post',
		array(
			'capability'        => 'edit_theme_options',
			'default'           => 'excerpt',
			'sanitize_callback' => function( $value ) {
				return 'excerpt' === $value || 'full' === $value ? $value : 'excerpt';
			},
		)
	);

	$wp_customize->add_control(
		'display_excerpt_or_full_post',
		array(
			'type'    => 'radio',
			'section' => 'excerpt_settings',
			'label'   => 'On Archive Pages, posts show:',
			'choices' => array(
				'excerpt' => 'Summary',
				'full'    => 'Full text',
			),
		)
	);
}
add_action( 'customize_register', 'mytheme_customize_register1' );

function my_site_title() {
	if (is_home()) { ?>
		<h1><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h1><?php
	} else { ?>
		<p><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name'); ?></a></p><?php
	}
}

function my_site_description() {
	$description = get_bloginfo( 'description', 'display' ); 
	if ( $description || is_customize_preview() ) { ?>
		<p><?php echo $description; ?></p>
	<?php }
	}
