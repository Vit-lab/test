<?php ?>
<section>
	<header>
		<h1>Ничего нет</h1>
	</header>
		<div>
			<p>Ниодного поста небыло найдено</p>
		</div>
	</section>
