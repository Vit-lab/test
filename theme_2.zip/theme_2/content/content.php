<?php
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header>
		<?php if (is_singular()) { 
			the_title('<h1>', '</h1>');
		} else {
			the_title(sprintf('<h2><a href="%s">', esc_url('')), '</a></h2>');
		} ?>
	</header>
		<div>
		<?php the_content(); ?>
		</div>
	<footer>
	</footer>
</article>
